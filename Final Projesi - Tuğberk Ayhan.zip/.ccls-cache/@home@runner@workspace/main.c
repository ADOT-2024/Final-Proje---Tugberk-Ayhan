#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main() {
    int tahmin, sayi;
    char cevap;

    srand(time(NULL));

    do {

        sayi = rand() % 100 + 1;


        printf("Aklimda tuttugum sayiyi tahmin edebilir misin? Sayi 1 ile 100 arasinda!: ");

        if (scanf("%d", &tahmin) != 1) {
            printf("Hey! Bu bir sayi bile degil! Sana oyun falan yok!");

            while(getchar() != '\n');
            continue;
        }


        if (tahmin < 1 || tahmin > 100) {
            printf("1 ile 100 arasinda dedim. Benimle dalga geciyorsun! Sana oyun yok!\n");
            continue;
        }

        if (tahmin == sayi) {
            printf("Wow, bir medyum falan olmalisin!!\n");
        } else {
            printf("Yok o degildi, tuttugum sayi suydu: %d\n", sayi);
        }

        printf("Sansini tekrar denemek ister misin? (Evet: e / Hayir: h): ");
        scanf(" %c", &cevap);

    } while (cevap == 'e' || cevap == 'E');

    printf("Olsun ya bir dahaki sefere tahmin edersin!\n");

    return 0;
}